package de.regnis.q.sequence.line.simplifier;

/**
 * @author Marc Strapetz
 */
public class QSequenceLineDummySimplifier implements QSequenceLineSimplifier {

	// Implemented ============================================================

	public byte[] simplify(byte[] bytes) {
		return bytes;
	}
}
