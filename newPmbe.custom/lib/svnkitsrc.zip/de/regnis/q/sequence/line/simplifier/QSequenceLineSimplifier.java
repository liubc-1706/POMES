package de.regnis.q.sequence.line.simplifier;

/**
 * @author Marc Strapetz
 */
public interface QSequenceLineSimplifier {
	byte[] simplify(byte[] bytes);
}
